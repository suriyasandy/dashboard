import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any
from data_processor import DataProcessor

class AlertEngine:
    """Generate and analyze alerts based on threshold configurations."""
    
    def __init__(self):
        self.processor = DataProcessor()
    
    def generate_alerts(self, trade_df: pd.DataFrame,
                       original_thresholds: pd.DataFrame,
                       adjusted_thresholds: pd.DataFrame) -> Dict[str, Any]:
        """
        Generate comprehensive alert analysis.
        
        Args:
            trade_df: Trade data DataFrame
            original_thresholds: Original threshold configuration
            adjusted_thresholds: Adjusted threshold configuration
            
        Returns:
            Dict containing alert analysis results
        """
        # Preprocess trade data
        processed_trade = self.processor.preprocess_trade_data(trade_df)
        
        # Merge with original thresholds
        merged_data = self.processor.merge_trade_threshold_data(
            processed_trade, 
            original_thresholds
        )
        
        # Apply adjusted thresholds
        adjusted_threshold_dict = {row['CURR']: row['AdjustedThreshold'] 
                                 for _, row in adjusted_thresholds.iterrows()}
        
        merged_data['AdjustedThreshold1'] = merged_data['Currency1'].map(
            lambda x: adjusted_threshold_dict.get(x, merged_data.loc[merged_data['Currency1'] == x, 'Currency1_Threshold'].iloc[0] if len(merged_data.loc[merged_data['Currency1'] == x]) > 0 else 0)
        )
        merged_data['AdjustedThreshold2'] = merged_data['Currency2'].map(
            lambda x: adjusted_threshold_dict.get(x, merged_data.loc[merged_data['Currency2'] == x, 'Currency2_Threshold'].iloc[0] if len(merged_data.loc[merged_data['Currency2'] == x]) > 0 else 0)
        )
        
        merged_data['AdjustedApplicableThreshold'] = np.maximum(
            merged_data['AdjustedThreshold1'].fillna(0),
            merged_data['AdjustedThreshold2'].fillna(0)
        )
        
        # Generate alerts for both threshold sets
        merged_data = self._apply_alert_logic(merged_data)
        
        # Separate outliers
        outliers = merged_data[merged_data['IsOutlier'] == True].copy()
        valid_data = merged_data[merged_data['IsOutlier'] == False].copy()
        
        # Calculate summary statistics
        summary = {
            'total_records': len(merged_data),
            'valid_records': len(valid_data),
            'outliers': len(outliers),
            'proposed_alerts': valid_data['ProposedAlert'].sum(),
            'adjusted_alerts': valid_data['AdjustedAlert'].sum()
        }
        
        return {
            'processed_data': merged_data,
            'valid_data': valid_data,
            'outliers': outliers,
            'summary': summary
        }
    
    def _apply_alert_logic(self, merged_df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply alert logic to merged data.
        
        Args:
            merged_df: Merged trade and threshold data
            
        Returns:
            DataFrame with alert flags
        """
        df = merged_df.copy()
        
        # Initialize alert columns
        df['ProposedAlert'] = False
        df['AdjustedAlert'] = False
        
        # For non-outliers, apply threshold logic
        valid_mask = df['DeviationPercent'].notna()
        
        # Proposed alerts (original thresholds)
        df.loc[valid_mask, 'ProposedAlert'] = (
            abs(df.loc[valid_mask, 'DeviationPercent']) > 
            df.loc[valid_mask, 'ApplicableThreshold']
        )
        
        # Adjusted alerts (adjusted thresholds)
        df.loc[valid_mask, 'AdjustedAlert'] = (
            abs(df.loc[valid_mask, 'DeviationPercent']) > 
            df.loc[valid_mask, 'AdjustedApplicableThreshold']
        )
        
        return df
    
    def generate_bucket_analysis(self, alert_results: Dict[str, Any],
                               adjusted_thresholds: pd.DataFrame) -> Dict[str, List[Dict]]:
        """
        Generate currency-wise alert bucketing analysis.
        
        Args:
            alert_results: Results from alert generation
            adjusted_thresholds: Adjusted threshold configuration
            
        Returns:
            Dict containing bucket analysis for each currency
        """
        bucket_analysis = {}
        processed_data = alert_results['processed_data']
        
        # Get unique currencies from the threshold data
        currencies = adjusted_thresholds['CURR'].unique()
        
        for currency in currencies:
            # Get threshold for this currency
            currency_threshold = adjusted_thresholds[
                adjusted_thresholds['CURR'] == currency
            ]['AdjustedThreshold'].iloc[0]
            
            # Find trades involving this currency
            currency_trades = processed_data[
                (processed_data['Currency1'] == currency) | 
                (processed_data['Currency2'] == currency)
            ].copy()
            
            if len(currency_trades) == 0:
                continue
            
            # Define bucket ranges based on threshold
            bucket_ranges = self._create_bucket_ranges(currency_threshold)
            
            # Categorize alerts into buckets
            buckets = []
            for i, (range_start, range_end) in enumerate(bucket_ranges):
                range_label = f"{range_start:.2f}-{range_end:.2f}"
                
                # Filter data for this bucket range
                bucket_mask = (
                    (abs(currency_trades['DeviationPercent']) >= range_start) & 
                    (abs(currency_trades['DeviationPercent']) < range_end) &
                    (currency_trades['DeviationPercent'].notna())
                )
                
                bucket_data = currency_trades[bucket_mask]
                
                # Count proposed and adjusted alerts in this bucket
                proposed_count = bucket_data['ProposedAlert'].sum()
                adjusted_count = bucket_data['AdjustedAlert'].sum()
                total_count = len(bucket_data)
                
                buckets.append({
                    'bucket_range': range_label,
                    'range_start': range_start,
                    'range_end': range_end,
                    'total_count': total_count,
                    'proposed_count': proposed_count,
                    'adjusted_count': adjusted_count,
                    'proposed_rate': (proposed_count / total_count * 100) if total_count > 0 else 0,
                    'adjusted_rate': (adjusted_count / total_count * 100) if total_count > 0 else 0
                })
            
            bucket_analysis[currency] = buckets
        
        return bucket_analysis
    
    def _create_bucket_ranges(self, threshold: float, num_buckets: int = 5) -> List[Tuple[float, float]]:
        """
        Create bucket ranges for alert analysis.
        
        Args:
            threshold: Threshold value for the currency
            num_buckets: Number of buckets to create
            
        Returns:
            List of (start, end) tuples defining bucket ranges
        """
        # Create ranges around the threshold
        ranges = []
        
        # Below threshold buckets
        step = threshold / (num_buckets // 2)
        for i in range(num_buckets // 2):
            start = i * step
            end = (i + 1) * step
            ranges.append((start, end))
        
        # Above threshold buckets
        above_step = threshold * 0.5  # Adjust this multiplier as needed
        for i in range(num_buckets // 2):
            start = threshold + (i * above_step)
            end = threshold + ((i + 1) * above_step)
            ranges.append((start, end))
        
        # Add a final bucket for very high deviations
        ranges.append((ranges[-1][1], float('inf')))
        
        return ranges
    
    def generate_summary_report(self, alert_results: Dict[str, Any],
                              trade_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate summary report by Legal Entity and Source System.
        
        Args:
            alert_results: Results from alert analysis
            trade_df: Original trade data
            
        Returns:
            DataFrame with summary metrics
        """
        processed_data = alert_results['processed_data']
        
        # Group by Legal Entity and Source System
        summary_groups = processed_data.groupby(['LegalEntity', 'SourceSystem']).agg({
            'Volume': 'sum',
            'ProposedAlert': 'sum',
            'AdjustedAlert': 'sum',
            'DeviationPercent': 'count'  # Total records
        }).reset_index()
        
        # Rename columns for clarity
        summary_groups.rename(columns={
            'Volume': 'TotalVolume',
            'ProposedAlert': 'ProposedAlerts',
            'AdjustedAlert': 'AdjustedAlerts',
            'DeviationPercent': 'TotalRecords'
        }, inplace=True)
        
        # Calculate alert rates
        summary_groups['ProposedAlertRate'] = (
            summary_groups['ProposedAlerts'] / summary_groups['TotalRecords'] * 100
        )
        summary_groups['AdjustedAlertRate'] = (
            summary_groups['AdjustedAlerts'] / summary_groups['TotalRecords'] * 100
        )
        
        # Calculate alert change
        summary_groups['AlertChange'] = (
            summary_groups['AdjustedAlerts'] - summary_groups['ProposedAlerts']
        )
        summary_groups['AlertChangePercent'] = (
            summary_groups['AlertChange'] / summary_groups['ProposedAlerts'] * 100
        ).fillna(0)
        
        return summary_groups
    
    def analyze_alert_distribution(self, alert_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze the distribution of alerts across various dimensions.
        
        Args:
            alert_results: Results from alert analysis
            
        Returns:
            Dict containing distribution analysis
        """
        processed_data = alert_results['processed_data']
        valid_data = alert_results['valid_data']
        
        distribution_analysis = {}
        
        # Alert distribution by Legal Entity
        le_distribution = valid_data.groupby('LegalEntity').agg({
            'ProposedAlert': ['sum', 'count'],
            'AdjustedAlert': ['sum', 'count']
        }).round(2)
        distribution_analysis['legal_entity'] = le_distribution
        
        # Alert distribution by Source System
        ss_distribution = valid_data.groupby('SourceSystem').agg({
            'ProposedAlert': ['sum', 'count'],
            'AdjustedAlert': ['sum', 'count']
        }).round(2)
        distribution_analysis['source_system'] = ss_distribution
        
        # Alert distribution by Currency Group
        if 'ApplicableGroup' in valid_data.columns:
            group_distribution = valid_data.groupby('ApplicableGroup').agg({
                'ProposedAlert': ['sum', 'count'],
                'AdjustedAlert': ['sum', 'count']
            }).round(2)
            distribution_analysis['currency_group'] = group_distribution
        
        # Temporal distribution (if date is available)
        if 'Date' in valid_data.columns:
            daily_distribution = valid_data.groupby('Date').agg({
                'ProposedAlert': 'sum',
                'AdjustedAlert': 'sum'
            })
            distribution_analysis['temporal'] = daily_distribution
        
        return distribution_analysis
    
    def calculate_alert_statistics(self, alert_results: Dict[str, Any]) -> Dict[str, float]:
        """
        Calculate detailed alert statistics.
        
        Args:
            alert_results: Results from alert analysis
            
        Returns:
            Dict containing statistical metrics
        """
        valid_data = alert_results['valid_data']
        
        if len(valid_data) == 0:
            return {}
        
        stats = {}
        
        # Basic counts
        stats['total_valid_records'] = len(valid_data)
        stats['proposed_alerts'] = valid_data['ProposedAlert'].sum()
        stats['adjusted_alerts'] = valid_data['AdjustedAlert'].sum()
        
        # Alert rates
        stats['proposed_alert_rate'] = (stats['proposed_alerts'] / stats['total_valid_records']) * 100
        stats['adjusted_alert_rate'] = (stats['adjusted_alerts'] / stats['total_valid_records']) * 100
        
        # Alert changes
        stats['alert_increase'] = stats['adjusted_alerts'] - stats['proposed_alerts']
        stats['alert_change_rate'] = (stats['alert_increase'] / stats['proposed_alerts'] * 100) if stats['proposed_alerts'] > 0 else 0
        
        # Deviation statistics
        stats['mean_deviation'] = valid_data['DeviationPercent'].mean()
        stats['median_deviation'] = valid_data['DeviationPercent'].median()
        stats['std_deviation'] = valid_data['DeviationPercent'].std()
        stats['max_deviation'] = valid_data['DeviationPercent'].max()
        stats['min_deviation'] = valid_data['DeviationPercent'].min()
        
        # Threshold statistics
        if 'ApplicableThreshold' in valid_data.columns:
            stats['mean_original_threshold'] = valid_data['ApplicableThreshold'].mean()
            stats['mean_adjusted_threshold'] = valid_data['AdjustedApplicableThreshold'].mean()
            stats['threshold_change'] = stats['mean_adjusted_threshold'] - stats['mean_original_threshold']
        
        return stats
