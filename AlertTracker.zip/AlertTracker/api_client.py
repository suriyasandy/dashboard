import pandas as pd
import requests
import os
import gzip
import shutil
import tempfile
from datetime import datetime, date, timedelta
from typing import Optional, Dict, Any, List
import json
from pathlib import Path
import concurrent.futures
from threading import Lock

class APIClient:
    """Handle API communications for downloading trade and exception data."""
    
    def __init__(self):
        # Get API configuration from environment variables
        self.base_url = os.getenv("API_BASE_URL", "https://api.example.com")
        self.api_key = os.getenv("API_KEY", "default_api_key")
        self.timeout = int(os.getenv("API_TIMEOUT", "30"))
        
        # Set up headers
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        # Create temporary directory for file operations
        self.temp_dir = tempfile.mkdtemp(prefix="trade_data_")
        self.download_lock = Lock()
    
    def download_trade_data(self, legal_entity: str, source_system: str,
                          start_date: date, end_date: date,
                          data_type: str = "BOTH") -> pd.DataFrame:
        """
        Download trade data from API.
        
        Args:
            legal_entity: Legal entity code (e.g., HBAP, HBEU)
            source_system: Source system code (e.g., PTS1, PTS2)
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            data_type: Type of data to download (UAT, PROD, or BOTH)
            
        Returns:
            DataFrame containing trade data
            
        Raises:
            Exception: If API call fails or returns invalid data
        """
        endpoint = f"{self.base_url}/trade-data"
        
        params = {
            "legal_entity": legal_entity,
            "source_system": source_system,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "data_type": data_type
        }
        
        try:
            response = requests.get(
                endpoint,
                headers=self.headers,
                params=params,
                timeout=self.timeout
            )
            
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            if "trade_data" not in data:
                raise ValueError("Invalid API response: missing trade_data field")
            
            # Convert to DataFrame
            df = pd.DataFrame(data["trade_data"])
            
            if df.empty:
                raise ValueError("No trade data returned from API")
            
            # Validate required columns
            required_columns = ['LegalEntity', 'SourceSystem', 'Date', 'Instrument', 'DeviationPercent', 'Volume', 'trade_id', 'alert_description']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                raise ValueError(f"Missing required columns in API response: {missing_columns}")
            
            return df
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Invalid JSON response from API: {str(e)}")
        except Exception as e:
            raise Exception(f"Error downloading trade data: {str(e)}")
    
    def download_exception_data(self, legal_entity: str, source_system: str,
                              start_date: date, end_date: date) -> pd.DataFrame:
        """
        Download exception data from API (PROD only).
        
        Args:
            legal_entity: Legal entity code
            source_system: Source system code
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            
        Returns:
            DataFrame containing exception data
            
        Raises:
            Exception: If API call fails or returns invalid data
        """
        endpoint = f"{self.base_url}/exception-data"
        
        params = {
            "legal_entity": legal_entity,
            "source_system": source_system,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "data_type": "PROD"  # Exception data is PROD only
        }
        
        try:
            response = requests.get(
                endpoint,
                headers=self.headers,
                params=params,
                timeout=self.timeout
            )
            
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            if "exception_data" not in data:
                raise ValueError("Invalid API response: missing exception_data field")
            
            # Convert to DataFrame
            df = pd.DataFrame(data["exception_data"])
            
            if df.empty:
                # Exception data can be empty, this is not an error
                return df
            
            return df
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Invalid JSON response from API: {str(e)}")
        except Exception as e:
            raise Exception(f"Error downloading exception data: {str(e)}")
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test API connection and authentication.
        
        Returns:
            Dict containing connection test results
        """
        endpoint = f"{self.base_url}/health"
        
        try:
            response = requests.get(
                endpoint,
                headers=self.headers,
                timeout=self.timeout
            )
            
            return {
                "status": "success",
                "status_code": response.status_code,
                "response_time": response.elapsed.total_seconds(),
                "api_version": response.headers.get("API-Version", "Unknown")
            }
            
        except requests.exceptions.RequestException as e:
            return {
                "status": "failed",
                "error": str(e),
                "response_time": None,
                "api_version": None
            }
    
    def get_available_legal_entities(self) -> list:
        """
        Get list of available legal entities from API.
        
        Returns:
            List of legal entity codes
        """
        endpoint = f"{self.base_url}/metadata/legal-entities"
        
        try:
            response = requests.get(
                endpoint,
                headers=self.headers,
                timeout=self.timeout
            )
            
            response.raise_for_status()
            data = response.json()
            
            return data.get("legal_entities", ["HBAP", "HBEU", "HBUS", "HBCA", "HBSG"])
            
        except Exception as e:
            # Return default list if API call fails
            return ["HBAP", "HBEU", "HBUS", "HBCA", "HBSG"]
    
    def get_available_source_systems(self) -> list:
        """
        Get list of available source systems from API.
        
        Returns:
            List of source system codes
        """
        endpoint = f"{self.base_url}/metadata/source-systems"
        
        try:
            response = requests.get(
                endpoint,
                headers=self.headers,
                timeout=self.timeout
            )
            
            response.raise_for_status()
            data = response.json()
            
            return data.get("source_systems", ["PTS1", "PTS2", "PTS3"])
            
        except Exception as e:
            # Return default list if API call fails
            return ["PTS1", "PTS2", "PTS3"]
    
    def validate_parameters(self, legal_entity: str, source_system: str,
                          start_date: date, end_date: date) -> Dict[str, Any]:
        """
        Validate API parameters before making requests.
        
        Args:
            legal_entity: Legal entity code
            source_system: Source system code
            start_date: Start date
            end_date: End date
            
        Returns:
            Dict containing validation results
        """
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Validate legal entity
        available_le = self.get_available_legal_entities()
        if legal_entity not in available_le:
            validation_result["errors"].append(
                f"Invalid legal entity: {legal_entity}. Available: {available_le}"
            )
            validation_result["is_valid"] = False
        
        # Validate source system
        available_ss = self.get_available_source_systems()
        if source_system not in available_ss:
            validation_result["errors"].append(
                f"Invalid source system: {source_system}. Available: {available_ss}"
            )
            validation_result["is_valid"] = False
        
        # Validate date range
        if start_date > end_date:
            validation_result["errors"].append(
                "Start date must be before or equal to end date"
            )
            validation_result["is_valid"] = False
        
        # Check if date range is too large (more than 90 days)
        date_diff = (end_date - start_date).days
        if date_diff > 90:
            validation_result["warnings"].append(
                f"Large date range ({date_diff} days) may result in slow API response"
            )
        
        # Check if dates are too far in the past
        days_ago = (date.today() - end_date).days
        if days_ago > 365:
            validation_result["warnings"].append(
                f"Requesting data from {days_ago} days ago - data may not be available"
            )
        
        return validation_result
    
    def download_data_async(self, legal_entity: str, source_system: str,
                          start_date: date, end_date: date) -> Dict[str, pd.DataFrame]:
        """
        Download both trade and exception data asynchronously.
        
        Args:
            legal_entity: Legal entity code
            source_system: Source system code
            start_date: Start date
            end_date: End date
            
        Returns:
            Dict containing both trade and exception DataFrames
        """
        results = {}
        errors = {}
        
        # Download trade data
        try:
            results["trade_data"] = self.download_trade_data(
                legal_entity, source_system, start_date, end_date
            )
        except Exception as e:
            errors["trade_data"] = str(e)
        
        # Download exception data
        try:
            results["exception_data"] = self.download_exception_data(
                legal_entity, source_system, start_date, end_date
            )
        except Exception as e:
            errors["exception_data"] = str(e)
        
        # Add error information to results
        if errors:
            results["errors"] = errors
        
        return results
    
    def download_single_file(self, legal_entity: str, source_system: str,
                           single_date: date, data_type: str = "UAT") -> Optional[str]:
        """
        Download a single file for a specific date and legal entity/source system.
        
        Args:
            legal_entity: Legal entity code
            source_system: Source system code
            single_date: Single date for data retrieval
            data_type: Type of data (UAT, PROD, or BOTH)
            
        Returns:
            Path to downloaded file or None if failed
        """
        endpoint = f"{self.base_url}/trade-data/single"
        
        params = {
            "legal_entity": legal_entity,
            "source_system": source_system,
            "date": single_date.isoformat(),
            "data_type": data_type,
            "format": "gzip"  # Request gzipped format
        }
        
        try:
            response = requests.get(
                endpoint,
                headers=self.headers,
                params=params,
                timeout=self.timeout,
                stream=True  # For large file downloads
            )
            
            response.raise_for_status()
            
            # Create filename
            filename = f"{legal_entity}_{source_system}_{data_type}_{single_date.isoformat()}.csv.gz"
            filepath = os.path.join(self.temp_dir, filename)
            
            # Download file
            with open(filepath, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            return filepath
            
        except Exception as e:
            print(f"Failed to download {filename}: {str(e)}")
            return None
    
    def extract_gzip_file(self, gzip_path: str) -> Optional[str]:
        """
        Extract gzipped CSV file and delete the original gzip file.
        
        Args:
            gzip_path: Path to the gzipped file
            
        Returns:
            Path to extracted CSV file or None if failed
        """
        try:
            if not gzip_path or not os.path.exists(gzip_path):
                return None
            
            # Create CSV filename
            csv_path = gzip_path.replace('.gz', '')
            
            # Extract gzip file
            with gzip.open(gzip_path, 'rb') as f_in:
                with open(csv_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            # Delete gzip file
            os.remove(gzip_path)
            
            return csv_path
            
        except Exception as e:
            print(f"Failed to extract {gzip_path}: {str(e)}")
            return None
    
    def download_batch_data(self, legal_entities: List[str], source_systems: List[str],
                          start_date: date, end_date: date, data_type: str = "UAT",
                          progress_callback=None) -> Dict[str, Any]:
        """
        Download trade data for multiple legal entities and source systems across date range.
        
        Args:
            legal_entities: List of legal entity codes
            source_systems: List of source system codes
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            data_type: Type of data (UAT, PROD, or BOTH)
            progress_callback: Callback function for progress updates
            
        Returns:
            Dict containing consolidated DataFrame and download statistics
        """
        download_stats = {
            "total_combinations": 0,
            "successful_downloads": 0,
            "failed_downloads": 0,
            "total_records": 0,
            "download_details": []
        }
        
        all_dataframes = []
        
        # Generate date range
        date_list = []
        current_date = start_date
        while current_date <= end_date:
            date_list.append(current_date)
            current_date += timedelta(days=1)
        
        # Calculate total combinations
        total_combinations = len(legal_entities) * len(source_systems) * len(date_list)
        download_stats["total_combinations"] = total_combinations
        
        completed = 0
        
        # Use ThreadPoolExecutor for parallel downloads
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            # Submit all download tasks
            future_to_params = {}
            
            for legal_entity in legal_entities:
                for source_system in source_systems:
                    for single_date in date_list:
                        future = executor.submit(
                            self.download_single_file,
                            legal_entity,
                            source_system,
                            single_date,
                            data_type
                        )
                        future_to_params[future] = {
                            "legal_entity": legal_entity,
                            "source_system": source_system,
                            "date": single_date,
                            "data_type": data_type
                        }
            
            # Process completed downloads
            for future in concurrent.futures.as_completed(future_to_params):
                params = future_to_params[future]
                completed += 1
                
                try:
                    gzip_path = future.result()
                    
                    if gzip_path:
                        # Extract the gzip file
                        csv_path = self.extract_gzip_file(gzip_path)
                        
                        if csv_path and os.path.exists(csv_path):
                            # Load the CSV data
                            try:
                                df = pd.read_csv(csv_path)
                                if not df.empty:
                                    all_dataframes.append(df)
                                    download_stats["total_records"] += len(df)
                                    download_stats["successful_downloads"] += 1
                                    
                                    download_stats["download_details"].append({
                                        "legal_entity": params["legal_entity"],
                                        "source_system": params["source_system"],
                                        "date": params["date"].isoformat(),
                                        "records": len(df),
                                        "status": "success"
                                    })
                                
                                # Clean up CSV file
                                os.remove(csv_path)
                                
                            except Exception as e:
                                download_stats["failed_downloads"] += 1
                                download_stats["download_details"].append({
                                    "legal_entity": params["legal_entity"],
                                    "source_system": params["source_system"],
                                    "date": params["date"].isoformat(),
                                    "records": 0,
                                    "status": f"csv_error: {str(e)}"
                                })
                        else:
                            download_stats["failed_downloads"] += 1
                            download_stats["download_details"].append({
                                "legal_entity": params["legal_entity"],
                                "source_system": params["source_system"],
                                "date": params["date"].isoformat(),
                                "records": 0,
                                "status": "extraction_failed"
                            })
                    else:
                        download_stats["failed_downloads"] += 1
                        download_stats["download_details"].append({
                            "legal_entity": params["legal_entity"],
                            "source_system": params["source_system"],
                            "date": params["date"].isoformat(),
                            "records": 0,
                            "status": "download_failed"
                        })
                
                except Exception as e:
                    download_stats["failed_downloads"] += 1
                    download_stats["download_details"].append({
                        "legal_entity": params["legal_entity"],
                        "source_system": params["source_system"],
                        "date": params["date"].isoformat(),
                        "records": 0,
                        "status": f"error: {str(e)}"
                    })
                
                # Update progress
                if progress_callback:
                    progress_callback(completed, total_combinations)
        
        # Consolidate all dataframes
        if all_dataframes:
            consolidated_df = pd.concat(all_dataframes, ignore_index=True)
            
            # Remove duplicates based on trade_id if column exists
            if 'trade_id' in consolidated_df.columns:
                original_count = len(consolidated_df)
                consolidated_df = consolidated_df.drop_duplicates(subset=['trade_id'])
                deduplicated_count = len(consolidated_df)
                download_stats["deduplicated_records"] = original_count - deduplicated_count
            
        else:
            consolidated_df = pd.DataFrame()
        
        return {
            "data": consolidated_df,
            "stats": download_stats
        }
    
    def download_batch_uat_and_prod(self, legal_entities: List[str], source_systems: List[str],
                                  start_date: date, end_date: date,
                                  progress_callback=None) -> Dict[str, Any]:
        """
        Download both UAT and PROD data for multiple entities/systems.
        
        Args:
            legal_entities: List of legal entity codes
            source_systems: List of source system codes
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            progress_callback: Callback function for progress updates
            
        Returns:
            Dict containing both UAT and PROD DataFrames and statistics
        """
        results = {}
        
        # Download UAT data
        if progress_callback:
            progress_callback(0, 100, "Downloading UAT data...")
        
        uat_result = self.download_batch_data(
            legal_entities, source_systems, start_date, end_date, "UAT",
            lambda completed, total: progress_callback(completed/total * 50, 100, f"UAT: {completed}/{total}")
        )
        
        results["uat_data"] = uat_result["data"]
        results["uat_stats"] = uat_result["stats"]
        
        # Download PROD data
        if progress_callback:
            progress_callback(50, 100, "Downloading PROD data...")
        
        prod_result = self.download_batch_data(
            legal_entities, source_systems, start_date, end_date, "PROD",
            lambda completed, total: progress_callback(50 + completed/total * 50, 100, f"PROD: {completed}/{total}")
        )
        
        results["prod_data"] = prod_result["data"]
        results["prod_stats"] = prod_result["stats"]
        
        return results
    
    def cleanup_temp_directory(self):
        """Clean up temporary directory and files."""
        try:
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
        except Exception as e:
            print(f"Failed to cleanup temp directory: {str(e)}")
    
    def __del__(self):
        """Cleanup when object is destroyed."""
        self.cleanup_temp_directory()
