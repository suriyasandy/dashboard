import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any

class ThresholdAnalyzer:
    """Analyze and manipulate threshold data for impact assessment."""
    
    def __init__(self):
        pass
    
    def group_by_group(self, threshold_df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """
        Group threshold data by GROUP column.
        
        Args:
            threshold_df: Threshold data DataFrame
            
        Returns:
            Dict mapping group names to DataFrames
        """
        grouped = {}
        
        for group_name in threshold_df['GROUP'].unique():
            group_data = threshold_df[threshold_df['GROUP'] == group_name].copy()
            grouped[group_name] = group_data
        
        return grouped
    
    def group_by_currency(self, threshold_df: pd.DataFrame) -> Dict[str, pd.Series]:
        """
        Group threshold data by currency.
        
        Args:
            threshold_df: Threshold data DataFrame
            
        Returns:
            Dict mapping currency codes to threshold information
        """
        currency_mapping = {}
        
        for _, row in threshold_df.iterrows():
            currency_mapping[row['CURR']] = row
        
        return currency_mapping
    
    def calculate_impact_preview(self, trade_df: pd.DataFrame, 
                               original_thresholds: pd.DataFrame,
                               adjusted_thresholds: pd.DataFrame) -> Dict[str, int]:
        """
        Calculate a preview of threshold impact on alerts.
        
        Args:
            trade_df: Trade data DataFrame
            original_thresholds: Original threshold configuration
            adjusted_thresholds: Adjusted threshold configuration
            
        Returns:
            Dict containing alert counts for original and adjusted thresholds
        """
        from data_processor import DataProcessor
        
        # Process trade data
        processor = DataProcessor()
        processed_trade = processor.preprocess_trade_data(trade_df)
        
        # Apply original thresholds
        merged_original = processor.merge_trade_threshold_data(
            processed_trade, 
            original_thresholds
        )
        
        # Count alerts with original thresholds
        original_alerts = self._count_alerts(merged_original, 'ApplicableThreshold')
        
        # Create adjusted threshold mapping
        adjusted_threshold_dict = {}
        for _, row in adjusted_thresholds.iterrows():
            adjusted_threshold_dict[row['CURR']] = row['AdjustedThreshold']
        
        # Apply adjusted thresholds
        merged_adjusted = merged_original.copy()
        merged_adjusted['AdjustedThreshold1'] = merged_adjusted['Currency1'].map(
            lambda x: adjusted_threshold_dict.get(x, merged_adjusted.loc[merged_adjusted['Currency1'] == x, 'Currency1_Threshold'].iloc[0] if len(merged_adjusted.loc[merged_adjusted['Currency1'] == x]) > 0 else 0)
        )
        merged_adjusted['AdjustedThreshold2'] = merged_adjusted['Currency2'].map(
            lambda x: adjusted_threshold_dict.get(x, merged_adjusted.loc[merged_adjusted['Currency2'] == x, 'Currency2_Threshold'].iloc[0] if len(merged_adjusted.loc[merged_adjusted['Currency2'] == x]) > 0 else 0)
        )
        
        merged_adjusted['AdjustedApplicableThreshold'] = np.maximum(
            merged_adjusted['AdjustedThreshold1'].fillna(0),
            merged_adjusted['AdjustedThreshold2'].fillna(0)
        )
        
        # Count alerts with adjusted thresholds
        adjusted_alerts = self._count_alerts(merged_adjusted, 'AdjustedApplicableThreshold')
        
        return {
            'proposed_alerts': original_alerts,
            'adjusted_alerts': adjusted_alerts
        }
    
    def _count_alerts(self, merged_df: pd.DataFrame, threshold_column: str) -> int:
        """
        Count alerts based on deviation percent exceeding threshold.
        
        Args:
            merged_df: Merged trade and threshold data
            threshold_column: Column name containing threshold values
            
        Returns:
            Number of alerts
        """
        # Filter out outliers (null deviation percent)
        valid_data = merged_df[merged_df['DeviationPercent'].notna()]
        
        # Count records where deviation exceeds threshold
        alerts = valid_data[
            abs(valid_data['DeviationPercent']) > valid_data[threshold_column]
        ]
        
        return len(alerts)
    
    def create_threshold_comparison_table(self, original_thresholds: pd.DataFrame,
                                        adjusted_thresholds: pd.DataFrame) -> pd.DataFrame:
        """
        Create a comparison table of original vs adjusted thresholds.
        
        Args:
            original_thresholds: Original threshold configuration
            adjusted_thresholds: Adjusted threshold configuration
            
        Returns:
            DataFrame with comparison information
        """
        comparison = original_thresholds.copy()
        
        # Map adjusted thresholds
        adjusted_mapping = {row['CURR']: row['AdjustedThreshold'] 
                          for _, row in adjusted_thresholds.iterrows()}
        
        comparison['AdjustedThreshold'] = comparison['CURR'].map(adjusted_mapping)
        comparison['ThresholdChange'] = comparison['AdjustedThreshold'] - comparison['Threshold']
        comparison['PercentChange'] = (comparison['ThresholdChange'] / comparison['Threshold']) * 100
        
        return comparison
    
    def analyze_group_impact(self, trade_df: pd.DataFrame,
                           threshold_comparison: pd.DataFrame) -> Dict[str, Dict]:
        """
        Analyze impact by threshold groups.
        
        Args:
            trade_df: Trade data DataFrame
            threshold_comparison: Threshold comparison table
            
        Returns:
            Dict containing impact analysis by group
        """
        group_impact = {}
        
        for group in threshold_comparison['GROUP'].unique():
            group_thresholds = threshold_comparison[threshold_comparison['GROUP'] == group]
            
            # Calculate group statistics
            group_stats = {
                'currencies': list(group_thresholds['CURR'].values),
                'original_threshold': group_thresholds['Threshold'].iloc[0],
                'adjusted_threshold': group_thresholds['AdjustedThreshold'].iloc[0],
                'threshold_change': group_thresholds['ThresholdChange'].iloc[0],
                'percent_change': group_thresholds['PercentChange'].iloc[0]
            }
            
            group_impact[group] = group_stats
        
        return group_impact
    
    def create_impact_matrix(self, alert_results: Dict, adjusted_thresholds: pd.DataFrame) -> np.ndarray:
        """
        Create an impact matrix for heatmap visualization.
        
        Args:
            alert_results: Results from alert analysis
            adjusted_thresholds: Adjusted threshold configuration
            
        Returns:
            2D numpy array for heatmap visualization
        """
        # Get unique groups and currencies
        groups = sorted(adjusted_thresholds['GROUP'].unique())
        currencies = sorted(adjusted_thresholds['CURR'].unique())
        
        # Create matrix
        matrix = np.zeros((len(groups), len(currencies)))
        
        # Fill matrix with threshold values
        for i, group in enumerate(groups):
            group_currencies = adjusted_thresholds[adjusted_thresholds['GROUP'] == group]['CURR'].values
            for j, currency in enumerate(currencies):
                if currency in group_currencies:
                    threshold_value = adjusted_thresholds[
                        (adjusted_thresholds['GROUP'] == group) & 
                        (adjusted_thresholds['CURR'] == currency)
                    ]['AdjustedThreshold'].iloc[0]
                    matrix[i, j] = threshold_value
        
        return matrix
    
    def calculate_sensitivity_analysis(self, trade_df: pd.DataFrame,
                                     threshold_df: pd.DataFrame,
                                     sensitivity_range: Tuple[float, float] = (0.8, 1.2),
                                     steps: int = 10) -> pd.DataFrame:
        """
        Perform sensitivity analysis on thresholds.
        
        Args:
            trade_df: Trade data DataFrame
            threshold_df: Threshold configuration
            sensitivity_range: Range of multipliers to test (min, max)
            steps: Number of steps in the sensitivity analysis
            
        Returns:
            DataFrame with sensitivity analysis results
        """
        from data_processor import DataProcessor
        
        processor = DataProcessor()
        processed_trade = processor.preprocess_trade_data(trade_df)
        
        # Generate multiplier values
        multipliers = np.linspace(sensitivity_range[0], sensitivity_range[1], steps)
        
        sensitivity_results = []
        
        for multiplier in multipliers:
            # Adjust all thresholds by the multiplier
            adjusted_thresholds = threshold_df.copy()
            adjusted_thresholds['AdjustedThreshold'] = adjusted_thresholds['Threshold'] * multiplier
            
            # Calculate alerts
            merged_data = processor.merge_trade_threshold_data(processed_trade, adjusted_thresholds)
            
            # Apply adjusted thresholds
            adjusted_threshold_dict = {row['CURR']: row['AdjustedThreshold'] 
                                     for _, row in adjusted_thresholds.iterrows()}
            
            merged_data['AdjustedThreshold1'] = merged_data['Currency1'].map(adjusted_threshold_dict)
            merged_data['AdjustedThreshold2'] = merged_data['Currency2'].map(adjusted_threshold_dict)
            merged_data['AdjustedApplicableThreshold'] = np.maximum(
                merged_data['AdjustedThreshold1'].fillna(0),
                merged_data['AdjustedThreshold2'].fillna(0)
            )
            
            alert_count = self._count_alerts(merged_data, 'AdjustedApplicableThreshold')
            
            sensitivity_results.append({
                'Multiplier': multiplier,
                'ThresholdMultiplier': f"{multiplier:.2f}x",
                'AlertCount': alert_count,
                'PercentChange': ((alert_count / len(merged_data)) * 100) if len(merged_data) > 0 else 0
            })
        
        return pd.DataFrame(sensitivity_results)
    
    def identify_threshold_outliers(self, threshold_df: pd.DataFrame) -> pd.DataFrame:
        """
        Identify threshold values that are statistical outliers.
        
        Args:
            threshold_df: Threshold configuration DataFrame
            
        Returns:
            DataFrame containing outlier threshold information
        """
        thresholds = threshold_df['Threshold'].values
        
        # Calculate IQR for outlier detection
        Q1 = np.percentile(thresholds, 25)
        Q3 = np.percentile(thresholds, 75)
        IQR = Q3 - Q1
        
        # Define outlier bounds
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        # Identify outliers
        outliers = threshold_df[
            (threshold_df['Threshold'] < lower_bound) | 
            (threshold_df['Threshold'] > upper_bound)
        ].copy()
        
        if len(outliers) > 0:
            outliers['OutlierType'] = np.where(
                outliers['Threshold'] < lower_bound, 
                'Low', 
                'High'
            )
            outliers['DistanceFromBound'] = np.where(
                outliers['Threshold'] < lower_bound,
                lower_bound - outliers['Threshold'],
                outliers['Threshold'] - upper_bound
            )
        
        return outliers
