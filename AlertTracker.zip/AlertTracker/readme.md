# Threshold Recalibration & Alert Impact Analysis App

## Overview

This is a Streamlit-based financial analytics application designed for threshold recalibration and alert impact analysis. The system processes trade data and exception data to analyze the impact of threshold adjustments on financial alerts. It supports both automated data download via API and manual file uploads, providing comprehensive threshold analysis capabilities for financial institutions.

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit web application
- **Multi-page Structure**: Four main sections (Data Input, Threshold Configuration, Alert Analysis, Reporting)
- **Interactive Components**: File uploads, parameter selection, data visualization with Plotly
- **Session State Management**: Persistent data storage across page navigation

### Backend Architecture
- **Modular Design**: Separated into specialized classes for different functionalities
- **Data Processing Pipeline**: Sequential processing from raw data to alert analysis
- **API Integration**: External data source connectivity for automated downloads
- **Business Logic Separation**: Clear separation between data processing, threshold analysis, and alert generation

## Key Components

### Data Layer
- **DataProcessor**: Handles file loading, validation, and preprocessing
  - Supports CSV and Excel file formats
  - Validates required columns for trade and threshold data
  - Implements data cleaning and standardization

### API Layer
- **APIClient**: Manages external API communications
  - Configurable via environment variables
  - Supports trade and exception data downloads
  - Implements authentication and error handling
  - **Batch Download Capability**: Downloads data for multiple legal entities and source systems
  - **File Processing**: Handles gzipped file extraction and cleanup
  - **Parallel Processing**: Concurrent downloads with progress tracking
  - **Data Consolidation**: Automatic merging and deduplication of downloaded files

### Business Logic Layer
- **ThresholdAnalyzer**: Performs threshold grouping and impact calculations
  - Groups thresholds by currency or group classification
  - Calculates impact previews for threshold adjustments
  
- **AlertEngine**: Generates comprehensive alert analysis
  - Merges trade data with threshold configurations
  - Applies adjusted thresholds and calculates alert impacts
  - Produces comparative analysis between original and adjusted thresholds

### Utility Layer
- **Utils**: Provides common formatting and helper functions
  - Number, percentage, and currency formatting
  - Data export and processing utilities

## Data Flow

1. **Data Input**: Users either upload files manually or select parameters for automated API download
2. **Data Validation**: System validates file formats and required columns
3. **Data Processing**: Raw data is cleaned, standardized, and preprocessed
4. **Threshold Configuration**: Users configure threshold groupings (currency-wise or group-wise)
5. **Threshold Adjustment**: Interactive threshold modification with real-time impact preview
6. **Alert Analysis**: System applies thresholds to trade data and generates alert comparisons
7. **Reporting**: Results are visualized and made available for export

## External Dependencies

### Required Libraries
- **Streamlit**: Web application framework
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computing
- **Plotly**: Interactive data visualization
- **Requests**: HTTP API communications

### Data Sources
- **External APIs**: Trade and exception data download endpoints
- **File Uploads**: Manual CSV/Excel file processing
- **Environment Configuration**: API keys and endpoint configuration

### Required Data Formats
- **Trade Dataset**: LegalEntity, SourceSystem, Date, Instrument, DeviationPercent, Volume, trade_id, alert_description
- **Threshold File**: LegalEntity, CURR, GROUP, Threshold
- **Exception Data**: Production environment data via API

### Data Processing Logic
- **UAT/PROD Matching**: When both UAT and PROD datasets are available, the system matches UAT records with PROD trade_ids
- **Scope Filtering**: Records containing "out of scope" (case insensitive) in alert_description are filtered out
- **Alert Application**: Thresholds are applied only after data matching and filtering
- **Batch Processing**: Supports multiple legal entities and source systems with consolidated data processing
- **Parallel Downloads**: Concurrent API calls with progress tracking and error handling
- **File Management**: Automatic gzip extraction, CSV processing, and temporary file cleanup

## Deployment Strategy

### Environment Setup
- Environment variables for API configuration (API_BASE_URL, API_KEY, API_TIMEOUT)
- Streamlit configuration for wide layout and custom page settings
- Session state management for data persistence

### Application Structure
- Single-page application with sidebar navigation
- Modular component initialization
- Error handling and user feedback mechanisms

### Data Security
- API authentication via Bearer tokens
- Environment-based configuration management
- Input validation and sanitization

### Scalability Considerations
- Modular architecture allows for easy component replacement
- API-based data access supports large-scale data processing
- Session state management enables handling of multiple concurrent users

## Key Features

- **Dual Data Input Options**: API automation or manual upload
- **Flexible Threshold Grouping**: Currency-wise or group-wise analysis
- **Real-time Impact Analysis**: Interactive threshold adjustment with immediate feedback
- **Comprehensive Reporting**: Visual analytics and export capabilities
- **Multi-environment Support**: UAT and PROD data processing