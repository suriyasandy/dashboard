import pandas as pd
import numpy as np
from typing import Union, Dict, Any
import io

class DataProcessor:
    """Handle data loading, validation, and preprocessing operations."""
    
    def __init__(self):
        self.required_trade_columns = [
            'LegalEntity', 'SourceSystem', 'Date', 'Instrument', 
            'DeviationPercent', 'Volume', 'trade_id', 'alert_description'
        ]
        self.required_threshold_columns = [
            'LegalEntity', 'CURR', 'GROUP', 'Threshold'
        ]
    
    def load_file(self, file) -> pd.DataFrame:
        """
        Load data from uploaded file (CSV or Excel).
        
        Args:
            file: Streamlit uploaded file object
            
        Returns:
            pd.DataFrame: Loaded and validated data
            
        Raises:
            ValueError: If file format is unsupported or data is invalid
        """
        try:
            # Determine file type and load accordingly
            if file.name.endswith('.csv'):
                df = pd.read_csv(file)
            elif file.name.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(file)
            else:
                raise ValueError(f"Unsupported file format: {file.name}")
            
            # Basic validation
            if df.empty:
                raise ValueError("File is empty")
            
            # Clean column names (remove extra spaces, standardize case)
            df.columns = df.columns.str.strip()
            
            return df
            
        except Exception as e:
            raise ValueError(f"Error loading file {file.name}: {str(e)}")
    
    def validate_trade_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate trade data structure and content.
        
        Args:
            df: Trade data DataFrame
            
        Returns:
            Dict containing validation results and statistics
        """
        validation_result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        # Check required columns
        missing_columns = []
        for col in self.required_trade_columns:
            if col not in df.columns:
                # Try to find similar column names
                similar_cols = [c for c in df.columns if col.lower() in c.lower()]
                if similar_cols:
                    validation_result['warnings'].append(
                        f"Required column '{col}' not found. Similar columns: {similar_cols}"
                    )
                else:
                    missing_columns.append(col)
        
        if missing_columns:
            validation_result['is_valid'] = False
            validation_result['errors'].append(
                f"Missing required columns: {missing_columns}"
            )
        
        # Data quality checks
        if validation_result['is_valid']:
            # Check for empty deviation percent (outliers)
            if 'DeviationPercent' in df.columns:
                null_deviation_count = df['DeviationPercent'].isnull().sum()
                validation_result['statistics']['outliers'] = null_deviation_count
                
                if null_deviation_count > 0:
                    validation_result['warnings'].append(
                        f"Found {null_deviation_count} records with empty DeviationPercent (outliers)"
                    )
            
            # Check date format
            if 'Date' in df.columns:
                try:
                    pd.to_datetime(df['Date'])
                except:
                    validation_result['warnings'].append(
                        "Date column may have formatting issues"
                    )
            
            # Basic statistics
            validation_result['statistics'].update({
                'total_records': len(df),
                'unique_legal_entities': df['LegalEntity'].nunique() if 'LegalEntity' in df.columns else 0,
                'unique_instruments': df['Instrument'].nunique() if 'Instrument' in df.columns else 0,
                'date_range': {
                    'start': df['Date'].min() if 'Date' in df.columns else None,
                    'end': df['Date'].max() if 'Date' in df.columns else None
                }
            })
        
        return validation_result
    
    def validate_threshold_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate threshold data structure and content.
        
        Args:
            df: Threshold data DataFrame
            
        Returns:
            Dict containing validation results and statistics
        """
        validation_result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        # Check required columns
        missing_columns = [col for col in self.required_threshold_columns if col not in df.columns]
        
        if missing_columns:
            validation_result['is_valid'] = False
            validation_result['errors'].append(
                f"Missing required columns: {missing_columns}"
            )
        
        # Data quality checks
        if validation_result['is_valid']:
            # Check for duplicate currency entries
            if 'CURR' in df.columns:
                duplicates = df['CURR'].duplicated().sum()
                if duplicates > 0:
                    duplicate_currencies = df[df['CURR'].duplicated(keep=False)]['CURR'].unique().tolist()
                    validation_result['warnings'].append(
                        f"Found {duplicates} duplicate currency entries: {duplicate_currencies}. The system will use the first occurrence of each currency."
                    )
                    validation_result['statistics']['duplicate_currencies'] = duplicate_currencies
            
            # Validate threshold values
            if 'Threshold' in df.columns:
                try:
                    thresholds = pd.to_numeric(df['Threshold'], errors='coerce')
                    invalid_thresholds = thresholds.isnull().sum()
                    
                    if invalid_thresholds > 0:
                        validation_result['errors'].append(
                            f"Found {invalid_thresholds} invalid threshold values"
                        )
                        validation_result['is_valid'] = False
                    
                    # Check for reasonable threshold ranges
                    if validation_result['is_valid']:
                        min_threshold = thresholds.min()
                        max_threshold = thresholds.max()
                        
                        if min_threshold < 0:
                            validation_result['warnings'].append(
                                "Found negative threshold values"
                            )
                        
                        if max_threshold > 1:
                            validation_result['warnings'].append(
                                "Found threshold values greater than 1 (100%)"
                            )
                        
                        validation_result['statistics']['threshold_range'] = {
                            'min': min_threshold,
                            'max': max_threshold,
                            'mean': thresholds.mean()
                        }
                
                except Exception as e:
                    validation_result['errors'].append(
                        f"Error validating threshold values: {str(e)}"
                    )
                    validation_result['is_valid'] = False
            
            # Basic statistics
            validation_result['statistics'].update({
                'total_currencies': len(df),
                'unique_groups': df['GROUP'].nunique() if 'GROUP' in df.columns else 0,
                'unique_legal_entities': df['LegalEntity'].nunique() if 'LegalEntity' in df.columns else 0
            })
        
        return validation_result
    
    def preprocess_trade_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Preprocess trade data for analysis.
        
        Args:
            df: Raw trade data DataFrame
            
        Returns:
            pd.DataFrame: Preprocessed trade data
        """
        df_processed = df.copy()
        
        # Convert date column to datetime
        if 'Date' in df_processed.columns:
            df_processed['Date'] = pd.to_datetime(df_processed['Date'])
        
        # Convert deviation percent to numeric
        if 'DeviationPercent' in df_processed.columns:
            df_processed['DeviationPercent'] = pd.to_numeric(
                df_processed['DeviationPercent'], 
                errors='coerce'
            )
        
        # Convert volume to numeric
        if 'Volume' in df_processed.columns:
            df_processed['Volume'] = pd.to_numeric(
                df_processed['Volume'], 
                errors='coerce'
            )
        
        # Extract currency pairs from instrument column
        if 'Instrument' in df_processed.columns:
            df_processed['Currency1'] = df_processed['Instrument'].str[:3]
            df_processed['Currency2'] = df_processed['Instrument'].str[3:6]
        
        # Mark outliers (empty deviation percent)
        if 'DeviationPercent' in df_processed.columns:
            df_processed['IsOutlier'] = df_processed['DeviationPercent'].isnull()
        
        return df_processed
    
    def match_and_filter_datasets(self, uat_data: pd.DataFrame, prod_data: pd.DataFrame) -> pd.DataFrame:
        """
        Match UAT and PROD datasets by trade_id and filter out 'out of scope' records.
        
        Args:
            uat_data: UAT trade data DataFrame
            prod_data: PROD trade data DataFrame
            
        Returns:
            pd.DataFrame: Filtered UAT data matching PROD trade_ids
        """
        if uat_data.empty or prod_data.empty:
            return uat_data
        
        # Get trade_ids from PROD data
        prod_trade_ids = set(prod_data['trade_id'].unique())
        
        # Filter UAT data to only include trade_ids that exist in PROD
        matched_uat = uat_data[uat_data['trade_id'].isin(prod_trade_ids)].copy()
        
        # Filter out records with 'out of scope' in alert_description (case insensitive)
        if 'alert_description' in matched_uat.columns:
            # Create a mask for records that do NOT contain 'out of scope'
            scope_mask = ~matched_uat['alert_description'].str.lower().str.contains(
                'out of scope', 
                na=False  # Treat NaN as False (keep records with no description)
            )
            matched_uat = matched_uat[scope_mask]
        
        return matched_uat
    
    def process_combined_datasets(self, uat_data: pd.DataFrame = None, 
                                prod_data: pd.DataFrame = None,
                                single_dataset: pd.DataFrame = None) -> pd.DataFrame:
        """
        Process trade datasets based on available data types.
        
        Args:
            uat_data: UAT trade data DataFrame (optional)
            prod_data: PROD trade data DataFrame (optional)
            single_dataset: Single dataset (if only one type is uploaded) (optional)
            
        Returns:
            pd.DataFrame: Processed trade data ready for analysis
        """
        if single_dataset is not None:
            # If only one dataset is provided, use it directly
            return self.preprocess_trade_data(single_dataset)
        
        elif uat_data is not None and prod_data is not None:
            # If both UAT and PROD are available, match and filter
            filtered_uat = self.match_and_filter_datasets(uat_data, prod_data)
            return self.preprocess_trade_data(filtered_uat)
        
        elif uat_data is not None:
            # Only UAT data available
            return self.preprocess_trade_data(uat_data)
        
        elif prod_data is not None:
            # Only PROD data available
            return self.preprocess_trade_data(prod_data)
        
        else:
            raise ValueError("No trade data provided")
    
    def preprocess_threshold_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Preprocess threshold data for analysis.
        
        Args:
            df: Raw threshold data DataFrame
            
        Returns:
            pd.DataFrame: Preprocessed threshold data
        """
        df_processed = df.copy()
        
        # Convert threshold to numeric
        if 'Threshold' in df_processed.columns:
            df_processed['Threshold'] = pd.to_numeric(df_processed['Threshold'])
        
        # Standardize currency codes (uppercase)
        if 'CURR' in df_processed.columns:
            df_processed['CURR'] = df_processed['CURR'].str.upper()
        
        # Convert group to string for consistency
        if 'GROUP' in df_processed.columns:
            df_processed['GROUP'] = df_processed['GROUP'].astype(str)
        
        return df_processed
    
    def merge_trade_threshold_data(self, trade_df: pd.DataFrame, threshold_df: pd.DataFrame) -> pd.DataFrame:
        """
        Merge trade data with threshold data based on currency mapping.
        
        Args:
            trade_df: Preprocessed trade data
            threshold_df: Preprocessed threshold data
            
        Returns:
            pd.DataFrame: Merged data with threshold information
        """
        merged_data = trade_df.copy()
        
        # Handle duplicate currencies by taking the first occurrence or aggregating if needed
        # First, check if there are duplicates in CURR column
        if threshold_df['CURR'].duplicated().any():
            print("Warning: Duplicate currencies found in threshold data. Using first occurrence for each currency.")
            # Keep first occurrence of each currency
            threshold_df_clean = threshold_df.drop_duplicates(subset=['CURR'], keep='first')
        else:
            threshold_df_clean = threshold_df.copy()
        
        # Create currency mapping for both currencies in the pair
        try:
            threshold_mapping = threshold_df_clean.set_index('CURR').to_dict('index')
        except ValueError as e:
            # If still getting duplicate index error, use groupby to aggregate
            print(f"Error creating threshold mapping: {e}")
            print("Aggregating duplicate currencies by taking maximum threshold value...")
            
            # Group by currency and take max threshold, first group, first legal entity
            threshold_agg = threshold_df.groupby('CURR').agg({
                'Threshold': 'max',  # Take maximum threshold for safety
                'GROUP': 'first',    # Take first group
                'LegalEntity': 'first'  # Take first legal entity
            }).reset_index()
            
            threshold_mapping = threshold_agg.set_index('CURR').to_dict('index')
        
        # Map thresholds for both currencies
        merged_data['Currency1_Group'] = merged_data['Currency1'].map(
            lambda x: threshold_mapping.get(x, {}).get('GROUP', None)
        )
        merged_data['Currency1_Threshold'] = merged_data['Currency1'].map(
            lambda x: threshold_mapping.get(x, {}).get('Threshold', None)
        )
        
        merged_data['Currency2_Group'] = merged_data['Currency2'].map(
            lambda x: threshold_mapping.get(x, {}).get('GROUP', None)
        )
        merged_data['Currency2_Threshold'] = merged_data['Currency2'].map(
            lambda x: threshold_mapping.get(x, {}).get('Threshold', None)
        )
        
        # For currency pairs, use the maximum threshold of the two currencies
        merged_data['ApplicableThreshold'] = np.maximum(
            merged_data['Currency1_Threshold'].fillna(0),
            merged_data['Currency2_Threshold'].fillna(0)
        )
        
        # Determine the applicable group (prefer the group with higher threshold)
        merged_data['ApplicableGroup'] = np.where(
            merged_data['Currency1_Threshold'].fillna(0) >= merged_data['Currency2_Threshold'].fillna(0),
            merged_data['Currency1_Group'],
            merged_data['Currency2_Group']
        )
        
        return merged_data
