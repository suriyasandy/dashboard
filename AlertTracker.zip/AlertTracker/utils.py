import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
import io
import base64
from datetime import datetime, date
import json

class Utils:
    """Utility functions for data processing and formatting."""
    
    @staticmethod
    def format_number(value: float, decimals: int = 2) -> str:
        """
        Format number with specified decimal places.
        
        Args:
            value: Number to format
            decimals: Number of decimal places
            
        Returns:
            Formatted number string
        """
        if pd.isna(value):
            return "N/A"
        
        return f"{value:,.{decimals}f}"
    
    @staticmethod
    def format_percentage(value: float, decimals: int = 2) -> str:
        """
        Format value as percentage.
        
        Args:
            value: Value to format (0.25 becomes 25.00%)
            decimals: Number of decimal places
            
        Returns:
            Formatted percentage string
        """
        if pd.isna(value):
            return "N/A"
        
        return f"{value:.{decimals}f}%"
    
    @staticmethod
    def format_currency(value: float, currency: str = "USD") -> str:
        """
        Format value as currency.
        
        Args:
            value: Value to format
            currency: Currency code
            
        Returns:
            Formatted currency string
        """
        if pd.isna(value):
            return "N/A"
        
        return f"{currency} {value:,.2f}"
    
    @staticmethod
    def create_download_link(df: pd.DataFrame, filename: str, 
                           file_format: str = "csv") -> str:
        """
        Create a download link for DataFrame.
        
        Args:
            df: DataFrame to download
            filename: Name of the file
            file_format: Format (csv or excel)
            
        Returns:
            Base64 encoded download link
        """
        if file_format.lower() == "csv":
            csv = df.to_csv(index=False)
            b64 = base64.b64encode(csv.encode()).decode()
            href = f'<a href="data:file/csv;base64,{b64}" download="{filename}.csv">Download CSV</a>'
        elif file_format.lower() == "excel":
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name='Data')
            excel_data = output.getvalue()
            b64 = base64.b64encode(excel_data).decode()
            href = f'<a href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{b64}" download="{filename}.xlsx">Download Excel</a>'
        else:
            raise ValueError(f"Unsupported file format: {file_format}")
        
        return href
    
    @staticmethod
    def validate_date_range(start_date: date, end_date: date) -> Dict[str, Any]:
        """
        Validate date range inputs.
        
        Args:
            start_date: Start date
            end_date: End date
            
        Returns:
            Dict containing validation results
        """
        validation = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Check if start date is before end date
        if start_date > end_date:
            validation["is_valid"] = False
            validation["errors"].append("Start date must be before or equal to end date")
        
        # Check if dates are in the future
        today = date.today()
        if start_date > today:
            validation["warnings"].append("Start date is in the future")
        if end_date > today:
            validation["warnings"].append("End date is in the future")
        
        # Check for very large date ranges
        days_diff = (end_date - start_date).days
        if days_diff > 365:
            validation["warnings"].append(f"Large date range ({days_diff} days) may impact performance")
        
        return validation
    
    @staticmethod
    def calculate_statistics(series: pd.Series) -> Dict[str, float]:
        """
        Calculate comprehensive statistics for a pandas Series.
        
        Args:
            series: Pandas Series to analyze
            
        Returns:
            Dict containing statistical measures
        """
        if series.empty or series.isnull().all():
            return {
                "count": 0,
                "mean": np.nan,
                "median": np.nan,
                "std": np.nan,
                "min": np.nan,
                "max": np.nan,
                "q25": np.nan,
                "q75": np.nan
            }
        
        return {
            "count": series.count(),
            "mean": series.mean(),
            "median": series.median(),
            "std": series.std(),
            "min": series.min(),
            "max": series.max(),
            "q25": series.quantile(0.25),
            "q75": series.quantile(0.75)
        }
    
    @staticmethod
    def create_summary_table(df: pd.DataFrame, group_columns: List[str],
                           agg_columns: Dict[str, str]) -> pd.DataFrame:
        """
        Create a summary table with grouping and aggregation.
        
        Args:
            df: DataFrame to summarize
            group_columns: Columns to group by
            agg_columns: Dict mapping column names to aggregation functions
            
        Returns:
            Summarized DataFrame
        """
        try:
            summary = df.groupby(group_columns).agg(agg_columns).reset_index()
            
            # Flatten multi-level column names if necessary
            if isinstance(summary.columns, pd.MultiIndex):
                summary.columns = ['_'.join(col).strip() for col in summary.columns.values]
            
            return summary
        except Exception as e:
            raise ValueError(f"Error creating summary table: {str(e)}")
    
    @staticmethod
    def detect_outliers(series: pd.Series, method: str = "iqr") -> pd.Series:
        """
        Detect outliers in a pandas Series.
        
        Args:
            series: Series to analyze
            method: Method to use ('iqr' or 'zscore')
            
        Returns:
            Boolean Series indicating outliers
        """
        if series.empty or series.isnull().all():
            return pd.Series([], dtype=bool)
        
        if method == "iqr":
            Q1 = series.quantile(0.25)
            Q3 = series.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            return (series < lower_bound) | (series > upper_bound)
        
        elif method == "zscore":
            z_scores = np.abs((series - series.mean()) / series.std())
            return z_scores > 3
        
        else:
            raise ValueError(f"Unsupported outlier detection method: {method}")
    
    @staticmethod
    def currency_pair_to_currencies(instrument: str) -> Tuple[str, str]:
        """
        Extract individual currencies from currency pair instrument.
        
        Args:
            instrument: Currency pair instrument (e.g., 'EURUSD')
            
        Returns:
            Tuple of (base_currency, quote_currency)
        """
        if not isinstance(instrument, str) or len(instrument) != 6:
            raise ValueError(f"Invalid currency pair format: {instrument}")
        
        base_currency = instrument[:3].upper()
        quote_currency = instrument[3:6].upper()
        
        return base_currency, quote_currency
    
    @staticmethod
    def validate_dataframe_structure(df: pd.DataFrame, 
                                   required_columns: List[str]) -> Dict[str, Any]:
        """
        Validate DataFrame structure against required columns.
        
        Args:
            df: DataFrame to validate
            required_columns: List of required column names
            
        Returns:
            Dict containing validation results
        """
        validation = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "missing_columns": [],
            "extra_columns": []
        }
        
        if df.empty:
            validation["is_valid"] = False
            validation["errors"].append("DataFrame is empty")
            return validation
        
        # Check for missing required columns
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            validation["is_valid"] = False
            validation["missing_columns"] = missing_columns
            validation["errors"].append(f"Missing required columns: {missing_columns}")
        
        # Identify extra columns
        extra_columns = [col for col in df.columns if col not in required_columns]
        if extra_columns:
            validation["extra_columns"] = extra_columns
            validation["warnings"].append(f"Extra columns found: {extra_columns}")
        
        return validation
    
    @staticmethod
    def safe_divide(numerator: float, denominator: float, 
                   default_value: float = 0.0) -> float:
        """
        Safely divide two numbers, handling division by zero.
        
        Args:
            numerator: Numerator value
            denominator: Denominator value
            default_value: Value to return if division by zero
            
        Returns:
            Result of division or default value
        """
        if pd.isna(numerator) or pd.isna(denominator) or denominator == 0:
            return default_value
        
        return numerator / denominator
    
    @staticmethod
    def format_timestamp(timestamp: datetime = None) -> str:
        """
        Format timestamp for file names and logs.
        
        Args:
            timestamp: Timestamp to format (default: current time)
            
        Returns:
            Formatted timestamp string
        """
        if timestamp is None:
            timestamp = datetime.now()
        
        return timestamp.strftime("%Y%m%d_%H%M%S")
    
    @staticmethod
    def convert_to_json_serializable(obj: Any) -> Any:
        """
        Convert object to JSON serializable format.
        
        Args:
            obj: Object to convert
            
        Returns:
            JSON serializable object
        """
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        elif isinstance(obj, pd.Timestamp):
            return obj.isoformat()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif pd.isna(obj):
            return None
        else:
            return obj
    
    @staticmethod
    def create_color_scale(values: List[float], 
                         colormap: str = "RdYlBu_r") -> List[str]:
        """
        Create color scale for visualizations.
        
        Args:
            values: List of values to map to colors
            colormap: Colormap name
            
        Returns:
            List of color codes
        """
        import plotly.colors as pc
        
        if not values:
            return []
        
        # Normalize values to [0, 1] range
        min_val = min(values)
        max_val = max(values)
        
        if min_val == max_val:
            # All values are the same
            return [pc.qualitative.Set1[0]] * len(values)
        
        normalized_values = [(v - min_val) / (max_val - min_val) for v in values]
        
        # Get colors from plotly colorscale
        colorscale = pc.get_colorscale(colormap)
        colors = []
        
        for norm_val in normalized_values:
            # Find appropriate color in colorscale
            for i in range(len(colorscale) - 1):
                if colorscale[i][0] <= norm_val <= colorscale[i + 1][0]:
                    colors.append(colorscale[i][1])
                    break
            else:
                colors.append(colorscale[-1][1])
        
        return colors
